declare module "@/style.css" {
  const style: string;
  export default style;
}
